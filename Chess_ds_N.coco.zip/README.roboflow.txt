
MOD_VISIOPE - v1 Chess_new_ds
==============================

This dataset was exported via roboflow.ai on May 8, 2022 at 5:52 PM GMT

It includes 699 images.
Chess are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


